# Editor demo

The Markdown draft shown in the VS Code screenshots for [Linting for everyone](https://jgagne.github.io/linting-for-everyone/).

## Get started

1. [Install Vale](https://docs.vale.sh/topics/quickstart).
2. Open this folder in VS Code.
3. Install the [Vale extension](https://marketplace.visualstudio.com/items?itemName=ChrisChinchilla.vale-vscode) and [markdownlint extension](https://marketplace.visualstudio.com/items?itemName=DavidAnson.vscode-markdownlint).
4. In Explorer, Control-click `_vale.ini` and choose **Rename**. Replace the underscore with a dot: `.vale.ini`.
5. Open [demo.md](demo.md), then open the Problems panel to review the findings.

After renaming, `.vale.ini` loads the bundled [Apify Vale styles](https://github.com/apify/vale-rules). No package download or `vale sync` is needed for this demo. Keep the bundled rules to reproduce this snapshot; updating them can change the findings.

## Compare the drafts

- [demo.md](demo.md): deliberately flawed writing, product names, links, and Markdown.
- [demo-fixed.md](demo-fixed.md): an editorial revision to compare with the original.
- [styles/](styles/): the YAML rules behind the Vale findings.

Run these commands from this folder:

```bash
vale demo.md
vale demo-fixed.md
```

Vale and markdownlint report different issues. A revised draft can still have Markdown findings; passing one tool does not mean the other passed.

These are teaching samples. Performance numbers and product claims are illustrative, not verified facts. The revision includes editorial changes, not only automatic fixes. Review meaning and evidence as well as lint findings.

## Try the browser version

For the smaller ProseLint Web example, use the separate [browser demo rules](https://github.com/jgagne/linting-for-everyone/tree/main/demo-rules).
