## Easy Google Maps scraping for lead generation

We're proud to announce our new Google Maps scraper. It isn't just a tool, it's a complete lead engine. Our scraper helps you extract leads instantly, and it's 10x faster than other tools. In this post, we delve into how it works.

It is important to note that scraping public data is legal in most jurisdictions. Cannot find what you need? Just click here to [here](https://apify.com/store).

### How it works

The actor runs on the apify platform and is used to analyse places such as restaurants, hotels, etc. Under the hood, it uses PlaywrightCrawler, so it's incredibly reliable — even on large searches. It is able to scrape various fields, see below.

- Contact details
- Opening hours
- Export your data and much more

To start, click on the Run button in the apify console. Exporting to a API from javascript is not supported.

Key takeaway: the scraper returns many results, highlighting its value. Send them tothe CRM of your choice.

![](https://blog.apify.com/content/images/google-maps-output.png)
