## Collect Google Maps leads for your sales team

Our Google Maps scraper returns business names, addresses, phone numbers, and opening hours for any search. A search for restaurants in Prague returns up to 500 places in about two minutes. This post explains how it works.

Scraping publicly available data is generally permitted, but you're responsible for how you use it. Can't find the data you need? Browse other scrapers in [Apify Store](https://apify.com/store).

### How it works

The Actor runs on the Apify platform and collects places such as restaurants and hotels. It runs a headless browser, so it handles pages that load content with scripts, even on large searches. It returns these fields:

- Contact details
- Opening hours
- Ratings and review counts

To start, select **Start** in Apify Console. To send results to your CRM, use the Apify API from JavaScript or Python.

Send the results to the CRM of your choice.

![Google Maps scraper results in Apify Console](https://blog.apify.com/content/images/google-maps-output.png)
